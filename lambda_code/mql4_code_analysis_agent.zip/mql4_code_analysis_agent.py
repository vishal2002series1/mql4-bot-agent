import boto3
import os
import json
import requests
from botocore.signers import RequestSigner

s3 = boto3.client('s3')

bedrock_endpoint = os.environ.get('BEDROCK_ENDPOINT')  # e.g. https://bedrock.us-east-1.amazonaws.com
model_id = os.environ.get('BEDROCK_MODEL_ID')          # e.g. 'anthropic.claude-v1'

def get_bedrock_response(prompt):
    session = boto3.Session()
    credentials = session.get_credentials()
    region = session.region_name or 'us-east-1'

    signer = RequestSigner(
        service_id='bedrock',
        region_name=region,
        signing_name='bedrock',
        signature_version='v4',
        credentials=credentials,
        event_emitter=session._events
    )

    request = {
        'method': 'POST',
        'url': f'{bedrock_endpoint}/models/{model_id}/invoke',
        'body': json.dumps({'inputText': prompt}),
        'headers': {
            'Content-Type': 'application/json'
        },
        'context': {}
    }

    signed_request = signer.sign(request)

    response = requests.post(
        signed_request['url'],
        data=signed_request['body'],
        headers=signed_request['headers']
    )

    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f'Bedrock API error: {response.status_code} {response.text}')

def lambda_handler(event, context):
    bucket = os.environ.get('BUCKET_NAME')
    key = os.environ.get('MQL4_CODE_FILE')

    try:
        # Read MQL4 code from S3
        response = s3.get_object(Bucket=bucket, Key=key)
        code_content = response['Body'].read().decode('utf-8')

        print("MQL4 Code read from S3 successfully.")

        # Prepare prompt for Bedrock LLM
        prompt = f"Analyze the following MQL4 Expert Advisor code and provide suggestions to maximize profit:\n\n{code_content}"

        # Call Bedrock LLM
        bedrock_response = get_bedrock_response(prompt)

        print("Bedrock LLM response:")
        print(json.dumps(bedrock_response, indent=2))

        return {
            'statusCode': 200,
            'body': bedrock_response
        }

    except Exception as e:
        print(f"Error: {e}")
        return {
            'statusCode': 500,
            'body': str(e)
        }